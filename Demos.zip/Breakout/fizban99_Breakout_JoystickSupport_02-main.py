from ssd1306 import initialize, clear_oled
from ssd1306_stamp import draw_stamp
from ssd1306_text import add_text
from ssd1306_bitmap import show_bitmap
from random import randint
import music
from microbit import sleep
from microbit_MicroPython_Joystick_Driver_01 import *
from machine import reset

# ---- stamps (5 wide only) ----
paddleL = bytearray(b'\x03\x03\x03\x03\x03')
paddleR = bytearray(b'\x03\x03\x03\x03\x03')
PADDLE_VIS_H = 2

ball = bytearray(b'\x00\x00\x18\x18\x00')
BW, BH = 2, 2
BALL_XOFF = 2
BALL_YOFF = 3

brick = bytearray(b'\xE0\xE0\xE0\xE0\xE0')
BRICK_W = 5
BRICK_VIS_H = 3

wipe = bytearray(b'\xFF\xFF\xFF\xFF\xFF')  # full-height wipe

W, H = 64, 32
STAMP_W = 5
MAX_X = 64 - STAMP_W  # 59 safe

# ---- field ----
TOP_PAD = 0
BR, BC = 3, 8
BXS, BYS = 7, 5
FIELD_W = (BC-1)*BXS + BRICK_W
BX0 = (W - FIELD_W)//2
BY0 = TOP_PAD

# paddle / serve
PY = 29
PW = 10
PADDLE_SPEED = 2  # << 2X speed, but applied as two 1px substeps

SERVE_SLOW_FRAMES = 40
serve_slow = 0
serve_toggle = 0

LIVES_START = 3

# ---- sounds ----
def s_fire(): music.pitch(1200,30); music.pitch(900,20)
def s_hit():  music.pitch(300,18)
def s_drop(): music.pitch(200,60)
def s_lose(): music.play(music.WAWAWAWAA)
def s_win():  music.pitch(700,35); music.pitch(900,35); music.pitch(1100,55)

def sticks():
    lb, rb = read_two_bytes()
    return decode_udflr_from_byte(lb), decode_udflr_from_byte(rb)

def wait_fire():
    while True:
        l, r = sticks()
        if l[2] or r[2]: break
        sleep(10)

def draw_paddle(x):
    draw_stamp(x,   PY, paddleL, 1, 1)
    draw_stamp(x+5, PY, paddleR, 1, 1)

def erase_paddle(x):
    # normal erase of paddle stamps
    draw_stamp(x,   PY, paddleL, 0, 0)
    draw_stamp(x+5, PY, paddleR, 0, 0)

def draw_bricks(on):
    for rr in range(BR):
        y = BY0 + rr*BYS
        for cc in range(BC):
            if on[rr][cc]:
                x = BX0 + cc*BXS
                draw_stamp(x, y, brick, 1, 1)

def hard_erase_brick(rr, cc):
    x0 = BX0 + cc*BXS
    y0 = BY0 + rr*BYS
    # wipe neighbor columns too to kill residue
    for xo in (x0-1, x0, x0+1):
        if 0 <= xo <= MAX_X:
            draw_stamp(xo, y0, wipe, 0, 1)

initialize()

# Boot splash
clear_oled()
#add_text(2, 1, "BREAKOUT", 1)
show_bitmap("breakout_splash_bitmap_128x64.bin")
sleep(800)

while True:
    score = 0
    lives = LIVES_START
    level = 1
    gameOver = False

    while not gameOver:

        # ---- Level title ----
        clear_oled()
        add_text(3, 1, "Level " + str(level), 1)  # your better placement
        sleep(700)
        clear_oled()

        on = [[1]*BC for _ in range(BR)]
        bricks_left = BC * BR
        draw_bricks(on)

        px = (W-PW)//2
        px0 = px
        draw_paddle(px)

        bx = px + PW//2 - 3
        by = PY - 5
        dx, dy = 0, -1
        launched = False
        seed_counter = 0
        serve_slow = 0
        serve_toggle = 0

        level_done = False
        while (not level_done) and (not gameOver):

            l, r = sticks()

            # ----- paddle move: 2 substeps, 1px each (no trails) -----
            move_dir = 0
            if l[3]: move_dir = -1
            elif l[4]: move_dir = 1

            if move_dir != 0:
                for _ in range(PADDLE_SPEED):
                    new_px = px + move_dir
                    if new_px < 0: new_px = 0
                    if new_px > (MAX_X - (PW-1)): new_px = (MAX_X - (PW-1))
                    if new_px != px:
                        erase_paddle(px)
                        px = new_px
                        draw_paddle(px)

            # ----- launch -----
            if not launched:
                seed_counter += 1
                if (r[2] or r[0]):
                    for _ in range(seed_counter & 0x0F):
                        randint(0,10)
                    dx = randint(-1,1)
                    if dx == 0 and randint(0,1): dx = 1
                    dy = -1
                    launched = True
                    serve_slow = SERVE_SLOW_FRAMES
                    serve_toggle = 0
                    s_fire()

            # ride paddle until launch
            if not launched:
                nbx = px + PW//2 - 3
                nby = PY - 5
                if nbx != bx or nby != by:
                    draw_stamp(bx, by, ball, 0, 0)
                    bx, by = nbx, nby
                    draw_stamp(bx, by, ball, 1, 1)
                sleep(10)
                continue

            # slow serve
            if serve_slow > 0:
                serve_toggle ^= 1
                serve_slow -= 1
                if serve_toggle == 0:
                    sleep(10)
                    continue

            # erase old ball
            draw_stamp(bx, by, ball, 0, 0)

            prev_x, prev_y = bx, by
            bx += dx
            by += dy

            # walls clamp
            if bx <= 0:
                bx = 0; dx = 1; s_hit()
            elif bx >= MAX_X:
                bx = MAX_X; dx = -1; s_hit()
            if by <= 0:
                by = 0; dy = 1; s_hit()

            # visual ball box
            prev_vx = prev_x + BALL_XOFF
            prev_vy = prev_y + BALL_YOFF
            vx = bx + BALL_XOFF
            vy = by + BALL_YOFF

            prev_top = prev_vy
            prev_bot = prev_vy + (BH-1)
            new_top  = vy
            new_bot  = vy + (BH-1)

            ball_left  = vx
            ball_right = vx + (BW-1)

            # ----- swept paddle collision using full overlap -----
            if dy > 0:
                if prev_bot < PY and new_bot >= PY:
                    if (ball_right >= px) and (ball_left <= px + PW - 1):
                        by = PY - (BALL_YOFF + BH)
                        vy = by + BALL_YOFF
                        dy = -1
                        s_hit()
                        mid = px + PW//2
                        cx = vx + 1
                        dx = -1 if cx < mid else 1

            # ----- swept brick collision + fallback overlap -----
            hit = False
            hit_rr = 0
            hit_cc = 0

            for rr in range(BR):
                y0 = BY0 + rr*BYS
                yb = y0 + (BRICK_VIS_H-1)

                crossed = False
                if dy < 0:
                    if prev_top > yb and new_top <= yb:
                        crossed = True
                else:
                    if prev_bot < y0 and new_bot >= y0:
                        crossed = True

                if crossed:
                    for cc in range(BC):
                        if not on[rr][cc]: continue
                        x0 = BX0 + cc*BXS
                        if x0 <= (vx+1) <= x0 + 4:
                            hit = True; hit_rr = rr; hit_cc = cc
                            break
                if hit: break

            # fallback AABB overlap after move (catches any missed case)
            if not hit:
                for rr in range(BR):
                    y0 = BY0 + rr*BYS
                    yb = y0 + (BRICK_VIS_H-1)
                    if y0 <= (vy+1) <= yb:
                        for cc in range(BC):
                            if not on[rr][cc]: continue
                            x0 = BX0 + cc*BXS
                            if x0 <= (vx+1) <= x0 + 4:
                                hit = True; hit_rr = rr; hit_cc = cc
                                break
                    if hit: break

            if hit:
                on[hit_rr][hit_cc] = 0
                hard_erase_brick(hit_rr, hit_cc)
                bricks_left -= 1
                score += 10
                dy = -dy
                if randint(0,3) == 0:
                    dx = -dx if dx != 0 else (1 if randint(0,1) else -1)
                s_hit()

            # lose ball
            if by > H-3:
                lives -= 1
                s_drop()
                if lives <= 0:
                    show_bitmap("game_over")
                    s_lose()
                    sleep(500)
                    clear_oled()
                    add_text(2, 1, "Score: " + str(score), 1)
                    gameOver = True
                    break
                else:
                    launched = False
                    bx = px + PW//2 - 3
                    by = PY - 5
                    dx, dy = 0, -1
                    serve_slow = 0
                    serve_toggle = 0
                    draw_stamp(bx, by, ball, 1, 1)
                    sleep(250)
                    continue
            else:
                draw_stamp(bx, by, ball, 1, 1)

            # level cleared?
            if bricks_left == 0:
                s_win()
                level += 1
                level_done = True
                break

            sleep(10)

    wait_fire()
    reset()
