# micro:bit "Makecode Python" version of joystick driver for microbit OLED badge


"""
The following code is simple driver to read the parallel to serial shift register based joysticks 
(each with 5 buttons, R, L, U, D, and fire)
the code can be simplified, but this is one way to read the joysticks on the badge
Note: GPIOs are handled differently in MicroPython vs. Makecode Python
this is the "Makecode Python" version, there is also a "MicroPython" version
"""

# FINAL BIT MAPPING:
# D0 -> UP, D1 -> DOWN, D2 -> FIRE, D3 -> LEFT, D4 -> RIGHT, D5..D7 tied high

# --- Pin mapping 
PIN_LATCH = DigitalPin.P8   # /PL (active low)
PIN_CLK   = DigitalPin.P9   # CP (rising edge shifts)
PIN_DATA  = DigitalPin.P16  # /Q7 (inverted: pressed -> 1)

# Idle states
pins.digitalWritePin(PIN_LATCH, 1)  # shift mode idle
pins.digitalWritePin(PIN_CLK, 0)    # clock idle low

def pulse_latch():
    # Latch current button states into the 165s
    pins.digitalWritePin(PIN_LATCH,0)
    basic.pause(1)
    pins.digitalWritePin(PIN_LATCH,1)

def read_two_bytes():
    """
    Read 16 bits from the daisy-chained 74LV165s into two bytes:
    First 8 clock cycles -> RIGHT byte (D7..D0)
    Next 8 clock cycles  -> LEFT  byte (D7..D0)
    We sample DATA before the rising edge; shift on rising edge.
    """
    pulse_latch()

    right_byte = 0
    left_byte  = 0

    # Read RIGHT (first 8 bits, MSB-first -> D7..D0)
    for i in range(8):
        bit = pins.digitalReadPin(PIN_DATA) & 1  # 1 = pressed (via /Q7)
        right_byte = (right_byte << 1) | bit
        pins.digitalWritePin(PIN_CLK, 1)
        pins.digitalWritePin(PIN_CLK, 0)

    # Read LEFT (next 8 bits)
    for i in range(8):
        bit = pins.digitalReadPin(PIN_DATA)  & 1
        left_byte = (left_byte << 1) | bit
        pins.digitalWritePin(PIN_CLK, 1)
        pins.digitalWritePin(PIN_CLK, 0)
 
    # After these loops:
    #   right_byte bits 7..0 == D7..D0 for RIGHT chip
    #   left_byte  bits 7..0 == D7..D0 for LEFT  chip
    return left_byte, right_byte

def btest(byte, bit_index):
    # Helper function, returns 1 if bit_index is set in byte, else 0.
    if (byte >> bit_index) & 1:
        return 1
    else:
        return 0

# Decode helpers: return 0/1 for U,D,F,L,R in fixed order
def decode_udflr_from_byte(byte_val):
    # byte_val bit mapping: bit0 = D0, bit1 = D1, ..., bit4 = D4
    up    = btest(byte_val, 0)   # D0
    down  = btest(byte_val, 1)   # D1
    fire  = btest(byte_val, 2)   # D2
    left  = btest(byte_val, 3)   # D3
    right = btest(byte_val, 4)   # D4
    # return list [U, D, F, L, R]
    return [up, down, fire, left, right]

