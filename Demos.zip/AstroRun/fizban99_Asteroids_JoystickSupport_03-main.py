from ssd1306 import initialize, clear_oled
from ssd1306_stamp import draw_stamp
from random import randint
from ssd1306_bitmap import show_bitmap
from ssd1306_text import add_text
import music
from microbit import sleep

from microbit_MicroPython_Joystick_Driver_01 import *
from machine import reset


# ---- SOUND EFFECTS ----
def snd_fire():
    music.pitch(1200, 30)
    music.pitch(900, 20)

def snd_explosion():
    music.pitch(200, 40)
    music.pitch(100, 40)
    music.pitch(300, 30)

def snd_game_over():
    music.play(music.WAWAWAWAA)

def snd_boot():
    music.play(music.POWER_UP)


def mv_stmp(x1, y1, x2, y2, stmp):
    draw_stamp(x1, y1, stmp, 0, 0)
    draw_stamp(x2, y2, stmp, 1, 1)


def init_star(i):
    return randint(0, 1), randint(0, 58), randint(1, 4)


def wait_for_fire():
    while True:
        left, right = read_two_bytes()
        left = decode_udflr_from_byte(left)
        right = decode_udflr_from_byte(right)
        if (left[2] or right[2]):
            break


# ----------------------------
# WEAPON CONFIG / STATE
# ----------------------------
MAX_SHOTS = 4
SHOT_SPEED = 2
FIRE_COOLDOWN = 2

laser = bytearray(b'\x00\x00\x18\x00\x00')

shot_x = [0] * MAX_SHOTS
shot_y = [0] * MAX_SHOTS
shot_on = [0] * MAX_SHOTS
fire_cool = 0

def spawn_shot(x0):
    for s in range(MAX_SHOTS):
        if not shot_on[s]:
            shot_on[s] = 1
            shot_x[s] = x0 - 2
            shot_y[s] = 20
            draw_stamp(shot_x[s], shot_y[s], laser, 1, 1)
            return


initialize()
show_bitmap("splash")
snd_boot()
wait_for_fire()

clear_oled()

starStamp = [bytearray(b'\x00\x60\xa0\x40\x00'),
             bytearray(b'\x00\xc0\xe0\x60\x00')]

ship = bytearray(b'\x40\xf0\x78\xf0\x40')

boom = bytearray(b'\x20\x70\xF8\x70\x20')
exp_timer = [0] * 5

starX, starY, star, speed = [0]*5, [0]*5, [0]*5, [0]*5
for i in range(5):
    star[i], starX[i], v = init_star(i)
    speed[i], starY[i] = v, -v

shipX, score, shipX0 = 32, 0, 32
gameOver = False

add_text(5, 0, str(score) + "  ", 1)


while not gameOver:
    for i in range(5):

        left_b, right_b = read_two_bytes()
        left  = decode_udflr_from_byte(left_b)
        right = decode_udflr_from_byte(right_b)

        if (left[3]) and shipX > 0:
            shipX -= 1
        if (left[4]) and shipX < 58:
            shipX += 1

        mv_stmp(shipX0, 23, shipX, 23, ship)
        shipX0 = shipX

        if fire_cool > 0:
            fire_cool -= 1

        if (right[2] or right[0]) and fire_cool == 0:
            snd_fire()
            spawn_shot(shipX + 2)
            fire_cool = FIRE_COOLDOWN


        for s in range(MAX_SHOTS):
            if shot_on[s]:
                draw_stamp(shot_x[s], shot_y[s], laser, 0, 0)
                shot_y[s] -= SHOT_SPEED
                if shot_y[s] < -8:
                    shot_on[s] = 0
                else:
                    draw_stamp(shot_x[s], shot_y[s], laser, 1, 1)


        x, y, v = starX[i], starY[i], speed[i]
        stmp = starStamp[star[i]]

        if exp_timer[i] > 0:
            draw_stamp(x, y, boom, 1, 1)
            exp_timer[i] -= 1
            if exp_timer[i] == 0:
                draw_stamp(x, y, boom, 0, 1)
                s2, x2, v2 = init_star(i)
                star[i] = s2
                starX[i] = x2
                starY[i] = -v2
                speed[i] = v2
            sleep(10)
            continue

        if y + v > 23:
            score += 1
            add_text(5, 0, str(score) + "  ", 1)
            draw_stamp(x, y, stmp, 0, 1)
            s2, x2, v2 = init_star(i)
            star[i] = s2
            stmp = starStamp[s2]
            starX[i] = x2
            starY[i], speed[i], y = -v2, v2, -v2
            x, v = x2, v2

        y0 = 0 if y == -v else y
        y = y + v
        starY[i] = y
        mv_stmp(x, y0, x, y, stmp)

        for s in range(MAX_SHOTS):
            if shot_on[s]:
                sx = shot_x[s]
                sy = shot_y[s]
                if (x <= sx+2 <= x+4) and (y <= sy <= y+7):
                    shot_on[s] = 0
                    draw_stamp(sx, sy, laser, 0, 0)
                    score += 10
                    add_text(5, 0, str(score) + "  ", 1)

                    snd_explosion()

                    draw_stamp(x, y, stmp, 0, 1)
                    exp_timer[i] = 2
                    draw_stamp(x, y, boom, 1, 1)
                    break


        if y > 19:
            if not ((x + 4 < shipX or shipX + 4 < x) or
                    (y + 7 < 27 or 31 < y + 4)):
                show_bitmap("game_over")
                snd_game_over()
                gameOver = True
                break

        sleep(10)

wait_for_fire()
reset()
