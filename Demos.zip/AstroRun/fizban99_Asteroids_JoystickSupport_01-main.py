from ssd1306 import initialize, clear_oled
from ssd1306_stamp import draw_stamp
from microbit import display as D
from random import randint
from ssd1306_bitmap import show_bitmap
from ssd1306_text import add_text

from microbit_MicroPython_Joystick_Driver_01 import *
from machine import reset

def mv_stmp(x1, y1, x2, y2, stmp):
    draw_stamp(x1, y1, stmp, 0, 0)
    draw_stamp(x2, y2, stmp, 1, 1)


def init_star(i):
    return randint(0, 1), randint(0, 58), randint(1, 4)

def wait_for_fire():
    # loop until a fire button is pressed
    while True:
        # add joystick support :)
        left, right = read_two_bytes()
        left = decode_udflr_from_byte( left )
        right = decode_udflr_from_byte( right )
        # check for Fire button, i.e press either joystick center button
        if (left[2] or right[2]):
            break        

initialize()
show_bitmap("splash")
wait_for_fire()

clear_oled()
starStamp = [bytearray(b'\x00\x60\xa0\x40\x00'),
             bytearray(b'\x00\xc0\xe0\x60\x00')]
ship = bytearray(b'\x40\xf0\x78\xf0\x40')
starX, starY, star, speed = [0] * 5, [0] * 5, [0] * 5, [0] * 5
for i in range(0, 5):
    star[i], starX[i], v = init_star(i)
    speed[i], starY[i] = v, -v
shipX,  score, shipX0 = 32,  0, 32
gameOver=False
add_text(5, 0, str(score) + "  ", 1)
while not gameOver:
    for i in range(0, 5):
        # read once per frame
        left_b, right_b = read_two_bytes()
        left  = decode_udflr_from_byte(left_b)
        right = decode_udflr_from_byte(right_b)

        # update ship once per frame
        if (left[3] or right[3]) and shipX > 0:
            shipX -= 1
        if (left[4] or right[4]) and shipX < 58:
            shipX += 1

        mv_stmp(shipX0, 23, shipX, 23, ship)
        shipX0 = shipX
        x, y, v = starX[i], starY[i], speed[i]
        stmp = starStamp[star[i]]
        if y + v > 23:
            score+=1
            add_text(5, 0, str(score) + "  ", 1)
            draw_stamp(x, y, stmp, 0, 1)
            s, x, v = init_star(i)
            star[i] = s
            stmp = starStamp[s]
            starX[i] = x
            starY[i], speed[i], y = -v, v, -v
        if y == -v:
            y0 = 0
        else:
            y0 = y
        y = y + v
        starY[i] = y
        mv_stmp(x, y0, x, y, stmp)
        if y > 19:
            if not ((x + 4 < shipX or shipX + 4 < x
                     ) or (y + 7 < 27 or 31 < y + 4)):
                show_bitmap("game_over")
                D.scroll("Score: " + str(score))
                gameOver=True
                break
        sleep(10)

wait_for_fire()        
reset()



        
