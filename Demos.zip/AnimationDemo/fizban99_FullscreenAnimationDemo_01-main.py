from ssd1306 import initialize, clear_oled
from random import randint
from ssd1306_bitmap import show_bitmap
from microbit import sleep

initialize()
while True:
    show_bitmap("frame_0.bin",0)
    sleep(100)
    show_bitmap("frame_1.bin",0)
    sleep(100)
    show_bitmap("frame_2.bin",0)
    sleep(100)
    show_bitmap("frame_3.bin",0)
    sleep(100)

