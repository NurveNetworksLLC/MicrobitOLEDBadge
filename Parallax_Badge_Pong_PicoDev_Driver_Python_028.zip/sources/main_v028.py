from PiicoDev_SSD1306 import *
from microbit import pin8, pin9, pin16, sleep, i2c
from random import randint
import music

# worlds slowest PONG! using the Picoodev driver found here:
# https://core-electronics.com.au/guides/micro-bit/piicodev-oled-ssd1306-microbit-guide/

# --------------------------------------------------------------

# following code is simple driver to read the parallel to serial shift register based joysticks (each with 5 buttons, R, L, U, D, and fire)
# the code can be simplified, but this is one way to read the joysticks on the badge
PIN_LATCH = pin8   # /PL (active low)
PIN_CLK   = pin9   # CP (rising edge shifts)
PIN_DATA  = pin16  # /Q7 (inverted: pressed -> 1)

# Idle states
PIN_LATCH.write_digital(1)  # shift mode idle
PIN_CLK.write_digital(0)    # clock idle low

# FINAL BIT MAPPING:
# D0 -> UP, D1 -> DOWN, D2 -> FIRE, D3 -> LEFT, D4 -> RIGHT, D5..D7 tied high

def pulse_latch():
    # Latch current button states into the 165s
    PIN_LATCH.write_digital(0)
    sleep(1)
    PIN_LATCH.write_digital(1)

def read_two_bytes():
    """
    Read 16 bits from the daisy-chained 74LV165s into two bytes:
    First 8 clock cycles -> RIGHT byte (D7..D0)
    Next 8 clock cycles  -> LEFT  byte (D7..D0)
    We sample DATA before the rising edge; shift on rising edge.
    """
    pulse_latch()

    right_byte = 0
    left_byte  = 0

    # Read RIGHT (first 8 bits, MSB-first -> D7..D0)
    for i in range(8):
        bit = PIN_DATA.read_digital() & 1  # 1 = pressed (via /Q7)
        right_byte = (right_byte << 1) | bit
        PIN_CLK.write_digital(1)
        PIN_CLK.write_digital(0)

    # Read LEFT (next 8 bits)
    for i in range(8):
        bit = PIN_DATA.read_digital() & 1
        left_byte = (left_byte << 1) | bit
        PIN_CLK.write_digital(1)
        PIN_CLK.write_digital(0)

    # After these loops:
    #   right_byte bits 7..0 == D7..D0 for RIGHT chip
    #   left_byte  bits 7..0 == D7..D0 for LEFT  chip
    return left_byte, right_byte

def btest(byte, bit_index):
    """Return 1 if bit_index is set in byte, else 0."""
    if (byte >> bit_index) & 1:
        return 1
    else:
        return 0

# Decode helpers: return 0/1 for U,D,F,L,R in fixed order
def decode_udflr_from_byte(byte_val):
    # byte_val bit mapping: bit0 = D0, bit1 = D1, ..., bit4 = D4
    up    = btest(byte_val, 0)   # D0
    down  = btest(byte_val, 1)   # D1
    fire  = btest(byte_val, 2)   # D2
    left  = btest(byte_val, 3)   # D3
    right = btest(byte_val, 4)   # D4
    # return list [U, D, F, L, R]
    return [up, down, fire, left, right]

# --------------------------------------------------------------

#create the display
display = create_PiicoDev_SSD1306()
i2c.init(freq=400000)

# screen size of our OLED
SCREEN_WIDTH = 128
SCREEN_HEIGHT = 64

# some variable for a little "mock" pong!
player1_x = int(SCREEN_WIDTH / 16)
player1_y = int(SCREEN_HEIGHT / 2)

player2_x = SCREEN_WIDTH - int(SCREEN_WIDTH / 16)
player2_y = int(SCREEN_HEIGHT / 2)

SPEED = 6
PADDLE_WIDTH = 4
PADDLE_HEIGHT = 12

# the ball
ball_x = randint(int(SCREEN_WIDTH / 2 - 4), int(SCREEN_WIDTH / 2 + 4) )
ball_y = randint(8, SCREEN_HEIGHT - 8 - 1) 

BALL_MAX_SPEED = 4

ball_xv = randint( -BALL_MAX_SPEED, BALL_MAX_SPEED )

while (ball_xv == 0 ):
    ball_xv = randint( -BALL_MAX_SPEED, BALL_MAX_SPEED )

ball_yv = randint( -BALL_MAX_SPEED, BALL_MAX_SPEED )

while (ball_yv == 0 ):
    ball_yv = randint( -BALL_MAX_SPEED, BALL_MAX_SPEED )

ball_xv = ball_xv * 2
ball_yv = ball_yv * 2

# score
player1_score = 0
player2_score = 0

# splash screen
display.fill(0)
display.text("micro:bit PONG!", 4, 12, 1)
display.text("version 0.28", 16, 24, 1)
display.text("PRESS DOWN TO,", 8, 40, 1)
display.text("TOGGLE SOUND FX", 0, 48, 1)

display.show()
sleep( 3000 );

# sound
set_volume( 128 )
sound_on = 1

# main event loop
while True:

    # clear screen
    display.fill(0)
    
    # move ball
    ball_x = ball_x + ball_xv
    ball_y = ball_y + ball_yv
        
    # Read joysticks raw data
    left_byte, right_byte = read_two_bytes()

    # Convert each byte to [U,D,F,L,R]
    left_list  = decode_udflr_from_byte(left_byte)
    right_list = decode_udflr_from_byte(right_byte)

    # check if players are moving?
    if (left_list[0] == 1):
        player1_y=player1_y-SPEED
    elif (left_list[1] == 1):
        player1_y=player1_y+SPEED
    elif (left_list[2] == 1):
        sound_on = -sound_on
        display.text("Sound on/off", 16, 24, 1)

    if (right_list[0] == 1):
        player2_y=player2_y-SPEED
    elif (right_list[1] == 1):
        player2_y=player2_y+SPEED
    elif (right_list[2] == 1):
        sound_on = -sound_on
        display.text("Sound on/off", 16, 24, 1)

    # check if paddles moving off screen
    if (player1_y >= SCREEN_HEIGHT - PADDLE_HEIGHT ):
        player1_y = SCREEN_HEIGHT - PADDLE_HEIGHT - 1
    if (player1_y < 0):
        player1_y = 0
    
    if (player2_y >= SCREEN_HEIGHT - PADDLE_HEIGHT):
        player2_y = SCREEN_HEIGHT - PADDLE_HEIGHT- 1
    if (player2_y < 0):
        player2_y = 0
    
    # check for paddle collisions

    # player 1 <-> ball collision
    if ( ( (ball_y >= player1_y and ball_y <= player1_y + PADDLE_HEIGHT) or
          (ball_y+4 >= player1_y and ball_y+4 <= player1_y + PADDLE_HEIGHT) ) and
          (ball_x >= player1_x and ball_x <= player1_x + PADDLE_WIDTH)):
        ball_xv = -ball_xv + randint(-1,1) 
        ball_x = ball_x + ball_xv
        if (sound_on == 1):music.pitch(200)
    
    # player 2 <-> ball collision
    elif ( ( (ball_y >= player2_y and ball_y <= player2_y + PADDLE_HEIGHT) or
          (ball_y+4 >= player2_y and ball_y+4 <= player2_y + PADDLE_HEIGHT) ) and
          (ball_x+4 >= player2_x and ball_x <= player2_x + PADDLE_WIDTH)):
        ball_xv = -ball_xv + randint(-1,1) 
        ball_x = ball_x + ball_xv
        if (sound_on == 1):music.pitch(200)
    
    # right and left boundaries
    if (ball_x < 0):
        ball_xv = -ball_xv
        ball_x = ball_x + ball_xv
        player2_score = player2_score + 1
    elif ((ball_x + 4) >= SCREEN_WIDTH):
        ball_xv = -ball_xv
        ball_x = ball_x + ball_xv
        player1_score = player1_score + 1

    # top and bottom boundaries
    if (ball_y < 0):
        ball_yv = -ball_yv
        ball_y = ball_y + ball_yv
    elif ((ball_y + 4) >= SCREEN_HEIGHT):
        ball_yv = -ball_yv
        ball_y = ball_y + ball_yv
        
    
        
    # draw paddles
    display.rect(int(player1_x),int(player1_y), PADDLE_WIDTH, PADDLE_HEIGHT, 1)
    display.rect(int(player2_x),int(player2_y), PADDLE_WIDTH, PADDLE_HEIGHT, 1)

    # draw net
    display.vline( int(SCREEN_WIDTH/2),0, SCREEN_HEIGHT-1, 1)
    
    # draw ball
    display.rect( ball_x, ball_y, 2, 2, 1 );

    music.stop()

    # draw score, VERY slow text
    display.text(str(player1_score), int(SCREEN_WIDTH / 2 ) - 24,0, 1)
    display.text(str(player2_score), int(SCREEN_WIDTH / 2 ) + 16,0, 1)
    
    # update the OLED
    display.show()
